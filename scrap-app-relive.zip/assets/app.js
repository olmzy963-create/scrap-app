
(function(){
'use strict';
function now(){ return new Date().toISOString(); }
function uid(){ return Math.random().toString(36).slice(2) + Date.now().toString(36); }
function byId(id){ return document.getElementById(id); }
function qs(sel){ return document.querySelector(sel); }
function toast(msg){ var c=byId('toasts'); if(!c){ c=document.createElement('div'); c.id='toasts'; document.body.appendChild(c);} var el=document.createElement('div'); el.className='toast'; el.textContent=msg; c.appendChild(el); setTimeout(function(){ if(el&&el.parentNode) el.parentNode.removeChild(el); }, 3000); }
function fileToDataURL(file, cb){ var r=new FileReader(); r.onload=function(){ cb(r.result); }; r.readAsDataURL(file); }

var STORAGE_KEY='scrapapp-db-relive';
var SESSION_KEY='scrapapp-session-relive';
function getDB(){ try{ var raw=localStorage.getItem(STORAGE_KEY); if(raw) return JSON.parse(raw); }catch(e){} var seed={ users:[], resident_profiles:[], business_profiles:[], jobs:[], listings:[], bids:[], messages:[], proofs:[], ratings:[] }; localStorage.setItem(STORAGE_KEY, JSON.stringify(seed)); return seed; }
function setDB(db){ localStorage.setItem(STORAGE_KEY, JSON.stringify(db)); }
function getSession(){ try{ var raw=localStorage.getItem(SESSION_KEY); return raw?JSON.parse(raw):null; }catch(e){ return null; } }
function setSession(s){ localStorage.setItem(SESSION_KEY, JSON.stringify(s)); }
function clearSession(){ localStorage.removeItem(SESSION_KEY); }

function currentUser(){ var s=getSession(); if(!s) return null; return getDB().users.find(function(u){ return u.id===s.user_id; })||null; }
function requireAuth(role){ var u=currentUser(); if(!u){ window.location.href='index.html'; return null; } if(role && u.role!==role){ window.location.href='index.html'; return null; } return u; }

function upsertResidentProfile(user_id,data){ var db=getDB(); var ex=db.resident_profiles.find(function(p){return p.user_id===user_id;}); if(ex){ for(var k in data) ex[k]=data[k]; } else { var o={ user_id:user_id }; for(var k2 in data) o[k2]=data[k2]; db.resident_profiles.push(o); } setDB(db); }
function getResidentProfile(uid_){ return getDB().resident_profiles.find(function(p){return p.user_id===uid_;})||null; }
function upsertBusinessProfile(user_id,data){ var db=getDB(); var ex=db.business_profiles.find(function(p){return p.user_id===user_id;}); if(ex){ for(var k in data) ex[k]=data[k]; } else { var o={ user_id:user_id, active_now:false, subscription_active:false, trial_start_at:null }; for(var k2 in data) o[k2]=data[k2]; db.business_profiles.push(o); } setDB(db); }
function getBusinessProfile(uid_){ return getDB().business_profiles.find(function(p){return p.user_id===uid_;})||null; }

function createJob(o){ var db=getDB(); var job={ id:uid(), resident_id:o.resident_id, title:o.title, notes:o.notes, photos:o.photos||[], lat:o.lat, lng:o.lng, address_text:o.address_text, status:'open', claimed_by:null, created_at:now(), updated_at:now() }; db.jobs.unshift(job); setDB(db); return job; }
function updateJob(id,patch){ var db=getDB(); var j=db.jobs.find(function(x){return x.id===id;}); if(j){ for(var k in patch){ j[k]=patch[k]; } j.updated_at=now(); setDB(db);} return j; }
function openJobs(){ return getDB().jobs.filter(function(j){return j.status==='open';}); }
function jobsForResident(uid_){ return getDB().jobs.filter(function(j){return j.resident_id===uid_;}); }
function jobsClaimedBy(uid_){ return getDB().jobs.filter(function(j){return j.claimed_by===uid_;}); }

function renderNav(){
  var u=currentUser(); var nav=document.getElementById('nav-links'); if(!nav) return;
  var auth=document.getElementById('auth-area'); 
  if(!u){ if(auth) auth.innerHTML='<a href=\"login.html\" class=\"btn btn-primary\">Sign in</a>'; return; }
  var label = (u.role==='resident' ? (getResidentProfile(u.id)&&getResidentProfile(u.id).name || u.email) : (getBusinessProfile(u.id)&&getBusinessProfile(u.id).company_name || u.email));
  if(auth){ auth.innerHTML='<span style=\"font-size:14px;color:#9ca3af;margin-right:8px\">'+(u.role==='resident'?'Resident':'Business')+': <span style=\"color:#e5e7eb\">'+label+'</span></span><button id=\"btn-logout\" class=\"btn btn-ghost\" type=\"button\">Log out</button>'; var lo=document.getElementById('btn-logout'); if(lo){ lo.onclick=function(){ clearSession(); window.location.href=\"index.html\"; }; } }
}
window.ScrapApp = {
  now:now, uid:uid, byId:byId, qs:qs, toast:toast,
  getDB:getDB, setDB:setDB, getSession:getSession, setSession:setSession, clearSession:clearSession, currentUser:currentUser, requireAuth:requireAuth,
  upsertResidentProfile:upsertResidentProfile, getResidentProfile:getResidentProfile,
  upsertBusinessProfile:upsertBusinessProfile, getBusinessProfile:getBusinessProfile,
  createJob:createJob, updateJob:updateJob, openJobs:openJobs, jobsForResident:jobsForResident, jobsClaimedBy:jobsClaimedBy,
  renderNav:renderNav, fileToDataURL:fileToDataURL
};
if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', renderNav); } else { renderNav(); }
})();
